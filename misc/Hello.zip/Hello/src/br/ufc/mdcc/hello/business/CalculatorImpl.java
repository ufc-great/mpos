package br.ufc.mdcc.hello.business;

import br.ufc.mdcc.hello.Input;

public final class CalculatorImpl implements Calculable{

	public int sum(Input input) {
		return input.getNumber1() + input.getNumber2();
	}

	public int subtration(Input input) {
		return input.getNumber1() - input.getNumber2();
	}

	public int multiplication(int number01, int number02) {
		return number01 * number02;
	}

	public double division(int number01, int number02) {
		return (double)number01 / (double)number02;
	}
}