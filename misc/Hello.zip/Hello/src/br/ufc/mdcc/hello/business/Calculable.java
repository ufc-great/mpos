package br.ufc.mdcc.hello.business;

import br.ufc.mdcc.hello.Input;

public interface Calculable {
	public int sum(Input input);
	
	public int subtration(Input input);
	
	public int multiplication(int number01, int number02);
	
	public double division(int number01, int number02);
}