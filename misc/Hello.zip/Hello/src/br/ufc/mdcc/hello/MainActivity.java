package br.ufc.mdcc.hello;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Process;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import br.ufc.mdcc.hello.business.Calculable;
import br.ufc.mdcc.hello.business.CalculatorImpl;

public class MainActivity extends Activity {
	 private final String clsName = MainActivity.class.getName();
	
	//business class
	private Calculable calc = new CalculatorImpl();
	private boolean quit = false;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		if (savedInstanceState == null) {
			getFragmentManager().beginTransaction()
					.add(R.id.container, new MainFragment()).commit();
		}
	}
	
	@Override
    protected void onDestroy() {
        super.onDestroy();
        
        if (quit) {
            //MposFramework.getInstance().stop();
            Process.killProcess(Process.myPid());
        }
    }
	
	public void onBackPressed() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(this);
        alertDialogBuilder.setTitle("Exit App?");
        alertDialogBuilder.setIcon(android.R.drawable.ic_dialog_alert);
        alertDialogBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                Log.i(clsName, "Calc finished");
                quit = true;
                finish();
            }
        });
        alertDialogBuilder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });

        alertDialogBuilder.setMessage("Do you want to exit?");
        alertDialogBuilder.create().show();
    }

	/**
	 * A placeholder fragment (MainFragment) containing a simple view.
	 */
	public final class MainFragment extends Fragment {

		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			View rootView = inflater.inflate(R.layout.fragment_main, container,
					false);
			
			initButtons(rootView);
			
			return rootView;
		}
		
		private void initButtons(View root){
			Button sumButton = (Button) root.findViewById(R.id.button_sum);
			sumButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					executeCommand("+");
				}
			});
			
			Button subButton = (Button) root.findViewById(R.id.button_sub);
			subButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					executeCommand("-");
				}
			});
			
			Button mulButton = (Button) root.findViewById(R.id.button_mul);
			mulButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					executeCommand("*");
				}
			});
			
			Button divButton = (Button) root.findViewById(R.id.button_div);
			divButton.setOnClickListener(new OnClickListener() {
				@Override
				public void onClick(View v) {
					executeCommand("/");
				}
			});
		}
		
		private void executeCommand(String function){
			View root = getView();
			EditText number01 = (EditText) root.findViewById(R.id.number1_et);
			EditText number02 = (EditText) root.findViewById(R.id.number2_et);
			
			Command command = new Command();
			command.input = new Input(number01.getText().toString(), number02.getText().toString());
			command.function = function;
			
			new CalculatorTask(root).execute(command);
		}
	}

	//helper object to transfer data from UI to backend process
	private final class Command {
		private Input input;
		private String function;
	}

	//your process is recommend executed in parallel the thread UI, to avoid exceptions
	private final class CalculatorTask extends AsyncTask<Command, Void, Object> {
		
		private View root;
		
		public CalculatorTask(View root) {
			this.root = root;
		}

		@Override
		protected Object doInBackground(Command... params) {
			Command command = params[0];
			
			switch (command.function) {
			case "+":
				return calc.sum(command.input);

			case "-":
				return calc.subtration(command.input);

			case "*":
				return calc.multiplication(command.input.getNumber1(),
						command.input.getNumber2());

			case "/":
				return calc.division(command.input.getNumber1(),
						command.input.getNumber2());
			}

			return null;
		}
		
		@Override
		protected void onPostExecute(Object result) {
			//show on UI
			TextView resultTv = (TextView)root.findViewById(R.id.result_tv);
			if(result==null){
				resultTv.setText("Error");
			}else{
				resultTv.setText(result.toString());
			}
		}
	}
}