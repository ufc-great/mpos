package br.ufc.mdcc.hello;

import java.io.Serializable;

public final class Input implements Serializable{
	private static final long serialVersionUID = -3076977522780308455L;
	
	private int number1,number2;

	public Input() {
		
	}
	
	public Input(String number1, String number2) {
		this.number1 = Integer.parseInt(number1);
		this.number2 = Integer.parseInt(number2);
	}

	public int getNumber1() {
		return number1;
	}

	public int getNumber2() {
		return number2;
	}
}