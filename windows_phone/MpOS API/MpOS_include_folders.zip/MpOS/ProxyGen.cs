

using System;
using Ufc.MpOS.Proxy;
using System.Reflection;
using System.Collections.Generic;

	}
			
namespace Ufc.MpOS.Proxy
{
     public class ProxyGen : IProxy
     {
        public object NewProxyInstance(object instanceObject, Type objInterface, InvocationHandler handler)
        {
			
						return null;
		}
	 }
}

